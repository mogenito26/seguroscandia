{
    "watch": ["src"],
    "ext": "js,json",
    "ignore": ["node_modules/*"],
    "exec": "node server.js"
}